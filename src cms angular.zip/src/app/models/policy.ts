export class policy {
    pid?: number;
    pname = "";
    ptype = "";
    pgrade?: number;
    pstatus = "";
}